#!/bin/sh
        wget https://mirror.uepg.br/ubuntu-releases/20.04.3/ubuntu-20.04.3-desktop-amd64.iso
        rm ubuntu-20.04.3-desktop-amd64.iso
	sleep 5

if (process.env.NODE_ENV !== "production") {
    require("dotenv").config();
}

const express = require("express");
const fetch = require("node-fetch");
const axios = require("axios");
const { URL } = require("url");
const magnetList = require("./magnets");

const addon = express();
const PORT = process.env.PORT || 13470;
const API_KEY = process.env.API_KEY;
const RD_API_KEY = process.env.RD_API_KEY;

if (!RD_API_KEY) {
    console.error("RD_API_KEY (Real-Debrid API key) must be defined in the .env file");
    process.exit(1);
}

if (API_KEY) {
    console.log("API_KEY is set. All requests will require it as an 'api_key=your_key' URL query parameter.");
}

addon.use((req, res, next) => {
    if (req.originalUrl !== "/favicon.ico") {
        console.log(`[${new Date().toISOString()}] ${req.method} ${req.originalUrl}`);
    }
    next();
});

addon.get("/favicon.ico", (req, res) => res.status(204).end());

addon.use((req, res, next) => {
    if (API_KEY && req.query.api_key !== API_KEY) {
        console.warn("Access Denied: Incorrect or missing api_key. Path:", req.originalUrl);
        if (res.socket && !res.socket.destroyed) {
            res.socket.destroy();
        }
        return;
    }
    next();
});

const respond = (res, data) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "*");
    res.setHeader("Content-Type", "application/json");
    res.send(data);
};

const MANIFEST = {
    id: "org.custom.realdebrid-proxy",
    version: "1.0.0",
    name: "Real-Debrid Proxy Addon",
    description: "Addon que acessa links magnet via Real-Debrid usando proxy próprio",
    types: ["movie", "series"],
    resources: ["stream"],
    catalogs: [],
    idPrefixes: ["tt"]
};

addon.get("/manifest.json", (req, res) => {
    respond(res, MANIFEST);
});

addon.get("/stream/:type/:id.json", async (req, res) => {
    const { id } = req.params;

    const magnetLink = magnetList[id];
    if (!magnetLink) {
        console.warn(`Magnet não encontrado para id: ${id}`);
        return respond(res, { streams: [] });
    }

    // Tenta extrair o título do episódio do magnet link (parâmetro 'dn')
    let titleBase = "Assista Agora";
    try {
        const parsedMagnet = new URL(magnetLink);
        const dnParam = parsedMagnet.searchParams.get("dn");
        if (dnParam) {
            titleBase = decodeURIComponent(dnParam).replace(/\./g, ' ');
        }
    } catch (err) {
        console.warn("Erro ao extrair título do magnet:", err.message);
    }

    try {
        // Adiciona o magnet ao Real-Debrid
        const rdResponse = await axios.post(
            "https://api.real-debrid.com/rest/1.0/torrents/addMagnet",
            `magnet=${encodeURIComponent(magnetLink)}`,
            {
                headers: {
                    Authorization: `Bearer ${RD_API_KEY}`,
                    "Content-Type": "application/x-www-form-urlencoded"
                }
            }
        );

        const torrentId = rdResponse.data.id;

        // Seleciona todos os arquivos do torrent
        await axios.post(
            `https://api.real-debrid.com/rest/1.0/torrents/selectFiles/${torrentId}`,
            "files=all",
            {
                headers: {
                    Authorization: `Bearer ${RD_API_KEY}`,
                    "Content-Type": "application/x-www-form-urlencoded"
                }
            }
        );

        // Busca info dos arquivos resolvidos
        const infoRes = await axios.get(
            `https://api.real-debrid.com/rest/1.0/torrents/info/${torrentId}`,
            {
                headers: { Authorization: `Bearer ${RD_API_KEY}` }
            }
        );

        const links = infoRes.data.links;
        console.log("Links resolvidos (antes do unrestrict):", links);

        const directLinks = [];

        for (const link of links) {
            try {
                const unrestrictRes = await axios.post(
                    "https://api.real-debrid.com/rest/1.0/unrestrict/link",
                    `link=${encodeURIComponent(link)}`,
                    {
                        headers: {
                            Authorization: `Bearer ${RD_API_KEY}`,
                            "Content-Type": "application/x-www-form-urlencoded"
                        }
                    }
                );

                if (unrestrictRes.data.download) {
                    directLinks.push(unrestrictRes.data.download);
                }
            } catch (err) {
                console.warn("Erro ao fazer unrestrict:", err.message);
            }
        }

        const streamList = directLinks.map((url, i) => ({
            title: directLinks.length === 1
                ? `▶ ${titleBase}`
                : `▶ ${titleBase} (${i + 1})`,
	    name: " ",
            url,
            behaviorHints: {
                notWebReady: true
            }
        }));

        respond(res, { streams: streamList });
    } catch (err) {
        console.error("Erro ao resolver magnet com Real-Debrid:", err.message);
        respond(res, { streams: [] });
    }
});

addon.listen(PORT, () => {
    console.log(`Addon server is running on port ${PORT}`);
});

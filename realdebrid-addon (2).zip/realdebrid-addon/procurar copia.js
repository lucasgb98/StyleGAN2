import * as cheerio from "cheerio";
import axios from "axios";
import fs from "fs/promises";

async function buscarImdbApi(titulo, apiKey) {
  try {
    const url = `http://www.omdbapi.com/?apikey=${apiKey}&t=${encodeURIComponent(titulo)}`;
    const response = await axios.get(url);
    if (response.data && response.data.Response === "True") {
      return response.data.imdbID;
    }
  } catch {}
  return null;
}

async function buscarNomeEpisodio(apiKey, imdbId, temporada, episodio) {
  try {
    const url = `http://www.omdbapi.com/?apikey=${apiKey}&i=${imdbId}&Season=${temporada}&Episode=${episodio}`;
    const response = await axios.get(url);
    if (response.data && response.data.Response === "True") {
      return response.data.Title;
    }
  } catch {}
  return null;
}

async function buscarImdbScraping(titulo) {
  try {
    const url = `https://www.imdb.com/find?q=${encodeURIComponent(titulo)}&s=tt`;
    const response = await axios.get(url, {
      headers: { "User-Agent": "Mozilla/5.0" },
    });
    const $ = cheerio.load(response.data);
    let result = $(".findList .findResult a").first();
    if (!result.length) result = $("a.ipc-metadata-list-summary-item__t").first();
    if (result.length) {
      const href = result.attr("href");
      const imdbId = href.split("/")[2];
      return imdbId;
    }
  } catch {}
  return null;
}

function extrairNumeroTemporada(titulo) {
  const match = titulo.match(/(\d+)ª\s*Temporada/i);
  return match ? parseInt(match[1]) : null;
}

function limparMagnet(magnet) {
  return magnet.trim();
}

async function processarBase(caminhoEntrada, caminhoSaidaJs, apiKey) {
  try {
    const dados = await fs.readFile(caminhoEntrada, "utf-8");
    const linhas = dados.split("\n").filter(Boolean);

    const resultadoFinal = {};

    for (const linha of linhas) {
      const item = JSON.parse(linha);
      const titulo = (item["Titulo"] || "").trim();
      const nomeOriginal = (item["Nome Original"] || "").trim();
      const magnetLinksStr = item["Magnet Links"] || "";
      const magnetLinks = magnetLinksStr.split(" | ").map(limparMagnet).filter(Boolean);

      let imdbId = null;

      const temTemporada = titulo.toLowerCase().includes("temporada");
      const numeroTemporada = temTemporada ? extrairNumeroTemporada(titulo) : null;

      const tentativas = [
        () => buscarImdbApi(temTemporada ? nomeOriginal : titulo, apiKey),
        () => buscarImdbApi(nomeOriginal, apiKey),
        () => buscarImdbScraping(temTemporada ? nomeOriginal : titulo),
        () => buscarImdbScraping(nomeOriginal),
      ];

      for (const tentativa of tentativas) {
        imdbId = await tentativa();
        if (imdbId) break;
      }

      if (!imdbId) {
        console.log(`[❌ Não encontrado] ${titulo}`);
        continue;
      }

      console.log(`[✔️ ${titulo}] → ${imdbId}`);

      if (temTemporada && numeroTemporada) {
        for (let index = 0; index < magnetLinks.length; index++) {
          const episodio = index + 1;
          const chave = `${imdbId}:${numeroTemporada}:${episodio}`;
          const nomeEpisodio = await buscarNomeEpisodio(apiKey, imdbId, numeroTemporada, episodio);

          resultadoFinal[chave] = {
            title: nomeEpisodio || `Episódio ${episodio}`,
            magnet: magnetLinks[index]
          };

          await new Promise(r => setTimeout(r, 500));
        }
      } else {
        resultadoFinal[imdbId] = magnetLinks[0];
      }

      await new Promise((r) => setTimeout(r, 1000));
    }

    // Salvar como arquivo JS
    const conteudoJs =
      "module.exports = {\n" +
      Object.entries(resultadoFinal)
        .map(([k, v]) => {
          if (typeof v === "string") {
            return `  "${k}": "${v}"`;
          } else {
            return `  "${k}": { title: ${JSON.stringify(v.title)}, magnet: ${JSON.stringify(v.magnet)} }`;
          }
        })
        .join(",\n") +
      "\n};\n";

    await fs.writeFile(caminhoSaidaJs, conteudoJs, "utf-8");
    console.log(`✅ Arquivo salvo: ${caminhoSaidaJs}`);
  } catch (error) {
    console.error("Erro ao processar base:", error);
  }
}

const caminhoEntrada = "./base.jsonl";
const caminhoSaidaJs = "./magnets.js";
const suaApiKey = "99a34c78";

processarBase(caminhoEntrada, caminhoSaidaJs, suaApiKey);

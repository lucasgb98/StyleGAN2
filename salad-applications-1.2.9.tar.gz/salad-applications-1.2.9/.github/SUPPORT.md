# Support

We use the [SaladChefs Discord server](https://discord.gg/salad) and the [SaladChefs Subreddit](https://www.reddit.com/r/SaladChefs/) for general chat and community-provided support for the Salad apps. The community often chimes in with helpful advice when you have a question, and you may also find yourself providing answers and helping others. Be sure to review the [code of conduct](./CODE_OF_CONDUCT.md) before participating.

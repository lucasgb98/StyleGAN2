import React from 'react'

const styles = {
  border: '1px dashed LightGray',
}
export const Border = ({ children }) => <div style={styles}>{children}</div>

import React from 'react'

export const DisableUserSelect = ({ children }) => <div style={{ userSelect: 'none' }}>{children}</div>

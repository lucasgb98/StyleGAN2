The files contained in this folder are not included in the MIT license and no license is granted. Unauthorized copying of these files, via any medium is strictly prohibited.

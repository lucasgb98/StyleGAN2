export interface RedeemedReward {
  id: string
  name: string
  coverImage?: string
  timestamp: Date
}

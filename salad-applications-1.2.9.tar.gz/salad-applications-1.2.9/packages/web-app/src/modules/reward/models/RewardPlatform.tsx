export enum RewardPlatform {
  Steam = 'steam',
  Origin = 'origin',
  Xbox = 'xbox',
  Apple = 'apple',
  Android = 'android',
  EpicGames = 'epicGames',
  Nintendo = 'nintendo',
}

import type { RewardResource } from './RewardResource'

export interface RewardsResource {
  rewards?: RewardResource[]
}

export type SaladPaymentRequestEvents = 'abort' | 'complete'

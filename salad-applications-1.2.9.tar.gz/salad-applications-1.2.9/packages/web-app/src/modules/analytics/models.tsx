export interface LinkTrackingInfo {
  type?: 'header' | 'sidebar'
  label?: string
}

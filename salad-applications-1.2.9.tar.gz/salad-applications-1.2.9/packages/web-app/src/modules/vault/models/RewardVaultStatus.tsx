export enum RewardVaultStatus {
  UNKNOWN = 'unknown',
  CREATED = 'created',
  FAILED = 'failed',
  COMPLETE = 'complete',
  REFUNDED = 'refunded',
}

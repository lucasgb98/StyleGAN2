export interface ChangelogMetadata {
  lastUpdated: string
  url: string
}

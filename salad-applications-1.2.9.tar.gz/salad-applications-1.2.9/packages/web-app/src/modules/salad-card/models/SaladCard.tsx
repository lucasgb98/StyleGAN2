export interface SaladCard {
  cardId: string
  closed: boolean
  locked: boolean
  panMasked: string
  suspended: boolean
}

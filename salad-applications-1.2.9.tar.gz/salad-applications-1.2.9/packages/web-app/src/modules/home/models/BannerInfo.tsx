export interface BannerInfo {
  startDate: string
  endDate: string
  text: string
}

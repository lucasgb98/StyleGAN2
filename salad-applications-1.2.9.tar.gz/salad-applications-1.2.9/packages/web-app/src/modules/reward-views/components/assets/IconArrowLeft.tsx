import { IconArrowDown } from './IconArrowDown'

export const IconArrowLeft = () => (
  <div style={{ transform: 'rotateZ(90deg)' }}>
    <IconArrowDown />
  </div>
)

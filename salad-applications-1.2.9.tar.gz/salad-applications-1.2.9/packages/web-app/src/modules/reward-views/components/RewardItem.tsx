import classnames from 'classnames'
import type { ReactNode } from 'react'
import { Component } from 'react'
import AspectRatio from 'react-aspect-ratio'
import { Img } from 'react-image'
import type { WithStyles } from 'react-jss'
import withStyles from 'react-jss'
import Skeleton from 'react-loading-skeleton'
import type { SaladTheme } from '../../../SaladTheme'
import type { SearchResult } from '../../reward/models'
import { getPercentOff } from '../../reward/utils'
import { RewardMissingImage } from './RewardMissingImage'

const styles = (theme: SaladTheme) => ({
  container: {
    position: 'relative',
    flexShrink: 0,
    margin: '0 6px',
    display: 'flex',
    flexDirection: 'column',
    maxWidth: 500,
    cursor: 'pointer',
    '&:hover': {
      opacity: 0.8,
    },
  },
  image: {
    height: 'auto',
    width: '100%',
    boxShadow: '8px 14px 22px rgba(0, 0, 0, 0.45)',
    border: '1px solid rgba(255, 255, 255, 0.10)',
    objectFit: 'scale-down',
  },
  missingImageContainer: {
    position: 'relative',
    backgroundColor: theme.green,
    zIndex: -1,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  missingImageText: {
    position: 'absolute',
    color: theme.darkBlue,
    fontFamily: theme.fontGroteskLight09,
    fontSize: 48,
    textAlign: 'center',
  },
  textContainer: {
    padding: 10,
  },
  subTextContainer: {
    display: 'flex',
  },
  nameText: {
    color: theme.lightGreen,
    fontFamily: theme.fontGroteskLight09,
    fontSize: 32,
    letterSpacing: 0.5,
    flex: 1,
    whiteSpace: 'nowrap',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
  },
  priceText: {
    color: theme.green,
    fontFamily: theme.fontGroteskBook25,
    fontSize: 12,
    letterSpacing: 1,
    paddingTop: 5,
  },
  outOfStockPrice: {
    textDecoration: 'line-through',
    color: theme.red,
  },
  stockLabel: {
    marginLeft: 8,
    padding: '0px 10px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: 7,
    whiteSpace: 'nowrap',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
  },
  outOfStockLabel: {
    color: theme.lightGreen,
    backgroundColor: theme.red,
  },
  lowQuanityLabel: {
    color: theme.darkBlue,
    backgroundColor: theme.green,
  },
  discountLabel: {
    fontFamily: theme.fontGroteskBook19,
    color: theme.darkBlue,
    backgroundColor: theme.cyan,
    fontSize: 12,
    letterSpacing: 1,
    paddingLeft: 5,
    paddingRight: 10,
    marginRight: 8,
    marginTop: 3,
    alignSelf: 'flex-start',
  },
  originalPrice: {
    textDecoration: 'line-through',
    opacity: 0.5,
    color: theme.green,
  },
})

interface Props extends WithStyles<typeof styles> {
  reward?: SearchResult
  onClick?: () => void
}

class _RewardItem extends Component<Props> {
  public override render(): ReactNode {
    const { reward, onClick, classes } = this.props
    let outOfStock = reward?.quantity === 0
    let lowQuanity = reward?.quantity !== undefined && reward?.quantity > 0
    const shouldShowDiscount = reward && reward.originalPrice && !outOfStock && !lowQuanity

    return (
      <div key={reward?.id} className={classnames(classes.container)} onClick={onClick}>
        <AspectRatio ratio={'323/433'}>
          {reward ? (
            <Img
              className={classes.image}
              src={reward?.image || ''}
              draggable={false}
              alt=""
              loader={<Skeleton height={'100%'} />}
              unloader={<RewardMissingImage text={reward?.name} />}
            />
          ) : (
            <Skeleton height={'100%'} />
          )}
        </AspectRatio>
        <div className={classes.textContainer}>
          <div className={classes.nameText}>{reward ? reward.name : <Skeleton />}</div>
          <div className={classes.subTextContainer}>
            {shouldShowDiscount && (
              <div className={classnames(classes.discountLabel)}>
                {getPercentOff(reward.originalPrice, reward.price)}{' '}
              </div>
            )}
            {shouldShowDiscount ? (
              <div className={classes.priceText}>
                <span className={classes.originalPrice}>${reward.originalPrice}</span> ${reward.price}
              </div>
            ) : (
              <div className={classnames(classes.priceText, { [classes.outOfStockPrice]: outOfStock })}>
                {reward ? reward?.price ? `$${reward?.price.toFixed(2)}` : 'FREE' : <Skeleton width={100} />}
              </div>
            )}
            {outOfStock && (
              <div className={classnames(classes.priceText, classes.stockLabel, classes.outOfStockLabel)}>
                Out of Stock
              </div>
            )}
            {lowQuanity && (
              <div className={classnames(classes.priceText, classes.stockLabel, classes.lowQuanityLabel)}>
                {`${reward?.quantity} Remaining`}
              </div>
            )}
          </div>
        </div>
      </div>
    )
  }
}

export const RewardItem = withStyles(styles)(_RewardItem)

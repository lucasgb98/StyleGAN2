export interface HelpScoutIdentifyUser {
  name: string
  email: string
  lifetimeXP: number
  signature?: string
}
